﻿// Uni C++.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// using namespace cv;
using namespace std;


int main()
{
        std::cout << R"(
 ____  ____  _     _____ _      _____  _     ____  _____ _____ ____  _      _____
/  _ \/  _ \/ \ |\/  __// \  /|/__ __\/ \ /\/  __\/  __//  __//  _ \/ \__/|/  __/
| / \|| | \|| | //|  \  | |\ ||  / \  | | |||  \/||  \  | |  _| / \|| |\/|||  \  
| |-||| |_/|| \// |  /_ | | \||  | |  | \_/||    /|  /_ | |_//| |-||| |  |||  /_ 
\_/ \|\____/\__/  \____\\_/  \|  \_/  \____/\_/\_\\____\\____\\_/ \|\_/  \|\____\
                                                                                     
)" << '\n';
        return 0;
}